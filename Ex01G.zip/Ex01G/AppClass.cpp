#include "AppClass.h"
void Application::InitVariables(void)
{
	m_pCameraMngr->SetPositionTargetAndUpward(vector3(0.0f, 0.0f, 30.0f), ZERO_V3, AXIS_Y);

	MyMesh* newMesh = new MyMesh();
	myMeshList.push_back(newMesh);
	myMeshList[0]->GenerateDiamond(2, 3, C_WHITE);
}
void Application::Update(void)
{
	//Update the system so it knows how much time has passed since the last call
	m_pSystem->Update();

	//Is the arcball active?
	ArcBall();

	//Is the first person camera active?
	CameraRotation();
}
void Application::Display(void)
{
	// Clear the screen
	ClearScreen();

	static float fAngle = 0.0f;
	static float numDiamond = 1;
	static float numSubdivisions = 3;
	static float radius = 5;

	static DWORD dstartTime = GetTickCount();
	DWORD dcurrentTime = GetTickCount();
	DWORD dTime = dcurrentTime - dstartTime;
	float fTime = dTime / 1000.0f;
	if (fTime >= 1)
	{
		dstartTime = GetTickCount();
		numDiamond++;
		numSubdivisions++;
		MyMesh* newMesh = new MyMesh();
		myMeshList.push_back(newMesh);
		myMeshList[numDiamond-1]->GenerateDiamond(2, numSubdivisions, C_WHITE);
		radius *= 1.025;
	}

	//camera projection
	matrix4 m4Projection = m_pCameraMngr->GetProjectionMatrix();
	matrix4 m4View = m_pCameraMngr->GetViewMatrix();

	/*Uncomment line below for an example of rotation, apply translation before rotation
	to make it rotate around the world and rotation before translation to make it revolve
	around itself.
	*/
	//m4Model = glm::rotate(m4Model, glm::radians(fAngle), vector3(0.0f, 0.0f, 1.0f));

	for (int i = 0; i < numDiamond; i++)
	{
		matrix4 m4Model = ToMatrix4(m_qArcBall);
		if (numDiamond == 1)
		{
			m4Model = glm::rotate(m4Model, glm::radians(fAngle), vector3(0.0f, 0.0f, 1.0f));
			m4Model = glm::translate(m4Model, vector3(0, 0, 0));
			m4Model = glm::rotate(m4Model, glm::radians(fAngle), vector3(0.0f, 1.0f, 0.0f));
			myMeshList[i]->Render(m4Projection, m4View, m4Model);
		}
		else
		{
			m4Model = glm::rotate(m4Model, glm::radians(fAngle), vector3(0.0f, 0.0f, 1.0f));
			m4Model = glm::translate(m4Model, vector3(cosf(2 * PI * i / numDiamond) * radius, sinf(2 * PI * i / numDiamond) * radius, 0));
			m4Model = glm::rotate(m4Model, glm::radians(fAngle), vector3(0.0f, 1.0f, 0.0f));
			myMeshList[i]->Render(m4Projection, m4View, m4Model);
		}
	}
		
	// draw a skybox
	m_pMeshMngr->AddSkyboxToRenderList();
	
	//render list call
	m_uRenderCallCount = m_pMeshMngr->Render();

	//clear the render list
	m_pMeshMngr->ClearRenderList();
	
	//draw gui
	DrawGUI();

	//Angle increment
	fAngle += 1.0f;
	
	//end the current frame (internally swaps the front and back buffers)
	m_pWindow->display();
}
void Application::Release(void)
{
	static int shapeCount = myMeshList.size();
	for (int i = 0; i < shapeCount; i++)
	{
		if (myMeshList[i] != nullptr)
		{
			delete myMeshList[i];
			myMeshList[i] = nullptr;
		}
	}
	//release GUI
	ShutdownGUI();
}